# Task ID: [ID]
# Title: [Title]
# Status: [pending|in-progress|done|deferred|blocked]
# Dependencies: [comma-separated list of dependency IDs]
# Priority: [priority]
# Description: [brief description]

## Details:
[Detailed implementation notes with specific requirements, approach, and deliverables]

## Test Strategy:
[How to verify this task is complete and working correctly]

## Acceptance Criteria:
- [Criterion 1]
- [Criterion 2]
- [Criterion 3]
